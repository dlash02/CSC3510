'use strict';

const today = new Date();

  // const date = new Date();
  // date.setDate(date.getDate() - 7);
  // return date;

console.log(today);
console.log(weekAgo);