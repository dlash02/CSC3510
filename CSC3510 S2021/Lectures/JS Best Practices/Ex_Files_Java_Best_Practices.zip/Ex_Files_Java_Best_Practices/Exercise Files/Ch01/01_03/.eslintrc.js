module.exports = {
  env: {
    es6: true
  },
  rules: {

  },
};