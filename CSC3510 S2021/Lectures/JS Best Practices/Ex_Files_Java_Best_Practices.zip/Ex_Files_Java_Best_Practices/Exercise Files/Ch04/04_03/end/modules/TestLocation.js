const TestLocation = {
  city: 'Alexandria',
  lat: 31.2156400,
  lon: 29.9552700,
};

export default TestLocation;