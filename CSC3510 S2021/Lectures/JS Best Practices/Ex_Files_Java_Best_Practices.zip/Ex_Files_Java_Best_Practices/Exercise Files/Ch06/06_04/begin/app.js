'use strict';

let guess = 28;

console.log(guess++);
console.log(++guess);
console.log(guess);
