'use strict';

let guess = 28;

// console.log(guess++);
// console.log(++guess);
// console.log(guess);

console.log(guess);
guess += 1;
guess += 1;
console.log(guess);
console.log(guess);
