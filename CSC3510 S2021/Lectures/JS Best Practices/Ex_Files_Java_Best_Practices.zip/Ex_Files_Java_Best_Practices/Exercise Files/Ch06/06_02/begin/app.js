'use strict';

const responses = {
  selection: false,
  code: "90046",
};

console.log(responses.selection == 0);
console.log(responses.code == 90046);
